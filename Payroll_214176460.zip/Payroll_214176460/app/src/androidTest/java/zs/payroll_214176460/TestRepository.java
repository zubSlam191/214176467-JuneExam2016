package zs.payroll_214176460;

import android.test.AndroidTestCase;

import junit.framework.Assert;

import java.util.Set;

import zs.payroll_214176460.conf.GetContext;
import zs.payroll_214176460.domain.Employee;
import zs.payroll_214176460.repositories.Employee.Impl.EmployeeRepositoryImpl;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class TestRepository extends AndroidTestCase {

    private static final String TAG="EMPLOYEES TEST";
    private long empNum;

    public void testCreateReadUpdateDelete() throws Exception {
        EmployeeRepositoryImpl repo = new EmployeeRepositoryImpl(GetContext.getStaticContext());

        Employee createEmail = new Employee
                .Builder()
                .name("Some", "Name")
                .numberOfDependants(10)
                .demographics("Male", "South African")
                .build();

        Employee insertedEntity = repo.save(createEmail);
        empNum = insertedEntity.getEmployeeNumber();
        Assert.assertNotNull(TAG + " CREATE", insertedEntity);

        Employee createEmailTwo = new Employee
                .Builder()
                .name("Another", "Name")
                .numberOfDependants(4)
                .demographics("Male", "South African")
                .build();

        Employee insertedEntityTwo  = repo.save(createEmailTwo);
        empNum = insertedEntityTwo.getEmployeeNumber();
        Assert.assertNotNull(TAG + " CREATE", createEmailTwo);

        Employee createEmailThree = new Employee
                .Builder()
                .name("example", "three")
                .numberOfDependants(11)
                .demographics("Male", "South African")
                .build();

        Employee insertedEntityThree = repo.save(createEmailThree);
        empNum = insertedEntityThree.getEmployeeNumber();
        Assert.assertNotNull(TAG + " CREATE", insertedEntityThree);

        //READ ALL
        Set<Employee> settings = repo.findAll();

        Assert.assertTrue(TAG + " READ ALL", settings.size() > 0);

        //READ ENTITY
        Employee entity = repo.findById(empNum);
        Assert.assertNotNull(TAG + " READ ENTITY " + "id = " + entity.getEmployeeNumber() + "\n" + "address =  " + entity.getFirstName() + "\n" + "desc = " +  entity);

        //UPDATE ENTITY
        Employee updateEntity = new Employee
                .Builder()
                .copy(entity)
                .address("different area", 123, 234)
                .build();
        System.out.println(entity.getAddress().getPhysicalAddress() + " " + entity.getAddress().getPostalAddress() + "\n" + entity.getAddress().getPostalCode());
        repo.update(updateEntity);
        Employee newEntity = repo.findById(empNum);
        Assert.assertEquals(TAG+ " UPDATE ENTITY","different area",newEntity.getAddress().getPhysicalAddress());

        // DELETE ENTITY
        repo.delete(updateEntity);
        Employee deletedEntity = repo.findById(empNum);
        Assert.assertNull(TAG+" DELETE",deletedEntity);

        //DELETE ALL ENTITIES
        int rowsAfter = repo.deleteAll();
        settings = repo.findAll();
        int allRows = settings.size();
        Assert.assertEquals(TAG + " DELETE ALL ENTITIES",allRows, 0);

    }


}
