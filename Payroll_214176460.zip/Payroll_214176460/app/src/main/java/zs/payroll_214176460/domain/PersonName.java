package zs.payroll_214176460.domain;

/**
 * Created by 214176460 on 6/1/2016.
 */
public interface PersonName {

    String firstName = null;
    String lastName = null;

    String getFirstName();
    String getLastName();
    void setFirstName(String value);
    void setLastName(String value);
}
