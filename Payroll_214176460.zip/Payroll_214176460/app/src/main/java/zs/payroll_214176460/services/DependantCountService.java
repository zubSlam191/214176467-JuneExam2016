package zs.payroll_214176460.services;

import android.app.IntentService;
import android.content.Intent;

import zs.payroll_214176460.conf.GetContext;
import zs.payroll_214176460.domain.Employee;
import zs.payroll_214176460.repositories.Employee.Impl.EmployeeRepositoryImpl;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class DependantCountService extends IntentService {

    public DependantCountService() {
        super("DependantCountService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        EmployeeRepositoryImpl empRepo = new EmployeeRepositoryImpl(GetContext.getStaticContext());

        if (intent != null) {

            String posCode = null;
            Employee specificPosition =  empRepo.findById(2);

        }
    }
}
