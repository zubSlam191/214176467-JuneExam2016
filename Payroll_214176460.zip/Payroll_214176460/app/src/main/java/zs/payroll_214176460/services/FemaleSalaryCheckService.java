package zs.payroll_214176460.services;

import android.app.IntentService;
import android.content.Intent;

import zs.payroll_214176460.conf.GetContext;
import zs.payroll_214176460.domain.Employee;
import zs.payroll_214176460.repositories.Employee.Impl.EmployeeRepositoryImpl;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class FemaleSalaryCheckService extends IntentService {
    public FemaleSalaryCheckService() {
        super("FemaleSalaryCheckService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        EmployeeRepositoryImpl empRepo = new EmployeeRepositoryImpl(GetContext.getStaticContext());

        if (intent != null) {



        }
    }
}
