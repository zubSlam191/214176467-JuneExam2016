package zs.payroll_214176460.domain;

import java.math.BigDecimal;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class Entries {
    private BigDecimal lowerBand, upperBand;
    private Integer taxPercentRate;
}
