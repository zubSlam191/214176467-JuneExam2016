package zs.payroll_214176460.domain;

/**
 * Created by 214176460 on 6/1/2016.
 */
public interface PersonIdentity {
    String getIdValue();
    String getIdType();
}
