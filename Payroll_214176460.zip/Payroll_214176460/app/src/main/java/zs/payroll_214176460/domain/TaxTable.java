package zs.payroll_214176460.domain;

import java.util.ArrayList;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class TaxTable {
    private String year;
    private ArrayList<Entries> entries;

    public TaxTable() {
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public ArrayList<Entries> getEntries() {
        return entries;
    }

    public void setEntries(ArrayList<Entries> entries) {
        this.entries = entries;
    }
}
