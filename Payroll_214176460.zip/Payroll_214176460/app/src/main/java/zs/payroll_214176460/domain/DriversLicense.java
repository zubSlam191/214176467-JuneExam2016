package zs.payroll_214176460.domain;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class DriversLicense implements PersonIdentity {
    @Override
    public String getIdValue() {
        return "1234a";
    }

    @Override
    public String getIdType() {
        return "Driver's license";
    }

}
