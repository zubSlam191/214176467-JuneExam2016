package zs.payroll_214176460.services;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import zs.payroll_214176460.conf.GetContext;
import zs.payroll_214176460.domain.Employee;
import zs.payroll_214176460.repositories.Employee.Impl.EmployeeRepositoryImpl;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class EmployeeDetailsService  extends IntentService{

    private static final String TAG =
            "zs.payroll_214176460.services";

    @Override
    protected void onHandleIntent(Intent arg0) {

        EmployeeRepositoryImpl empRepo = new EmployeeRepositoryImpl(GetContext.getStaticContext());

        int empNum = 0;

        Employee emp  = empRepo.findById(empNum);




        Log.i(TAG, "empDetails");
    }

    String getEmpNames(Employee employee){
        return "Name: "+employee.getFirstName()+ " " + employee.getLastName();
    }

    String getDemographics(Employee employee){
        return "Demographics: " + employee.getDemographics().getGender()+" "+employee.getDemographics().getRace();
    }

    String getContact(Employee employee){
        return "Contact: " + employee.getContact().getCellNumber() + " " + employee.getContact().getHomeNumber();
    }

    String getAddress(Employee employee){
        return "Address: " + employee.getAddress().getPhysicalAddress() + " " + employee.getAddress().getPostalAddress() + " " + employee.getAddress().getPostalCode();
    }

    public EmployeeDetailsService() {
        super("Employee Details");
    }
}
