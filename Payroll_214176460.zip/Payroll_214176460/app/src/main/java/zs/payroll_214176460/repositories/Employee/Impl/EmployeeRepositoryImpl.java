package zs.payroll_214176460.repositories.Employee.Impl;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import zs.payroll_214176460.conf.DBConstants;
import zs.payroll_214176460.domain.Employee;
import zs.payroll_214176460.repositories.Employee.EmployeeRepository;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class EmployeeRepositoryImpl extends SQLiteOpenHelper implements EmployeeRepository {
    public static final String TABLE_EMPLOYEES = "employees";
    private SQLiteDatabase db;
    public static final String COLUMN_EMPLOYEE_NUMBER = "empNum";
    public static final String COLUMN_FIRST_NAME = "name";
    public static final String COLUMN_LAST_NAME = "surname";
    public static final String COLUMN_NUMBER_OF_DEPENDANTS = "depNum";
    public static final String COLUMN_JOB = "job";
    public static final String COLUMN_POSITION_CODE = "posCode";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_BENEFITS = "benefits";
    public static final String COLUMN_DEDUCTIONS = "deductions";
    public static final String COLUMN_SALARY = "salary";
    public static final String COLUMN_CELL_NUMBER = "cell";
    public static final String COLUMN_HOME_NUMBER = "homeNum";
    public static final String COLUMN_ADDRESS = "address";
    public static final String COLUMN_POST_ADDRESS = "pAddress";
    public static final String COLUMN_POSTAL_CODE = "pCode";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_RACE = "race";





    // Database creation sql statement
    private static final String DATABASE_CREATE = " CREATE TABLE "
            + TABLE_EMPLOYEES + "("
            +COLUMN_EMPLOYEE_NUMBER + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_FIRST_NAME + " TEXT NOT NULL , "
            + COLUMN_LAST_NAME + " TEXT NOT NULL , "
            + COLUMN_NUMBER_OF_DEPENDANTS + " INTEGER NOT NULL , "
            + COLUMN_JOB + " TEXT NOT NULL , "
            + COLUMN_POSITION_CODE + " TEXT NOT NULL , "
            + COLUMN_STATUS + " TEXT NOT NULL , "
            + COLUMN_BENEFITS + " INTEGER NOT NULL , "
            + COLUMN_DEDUCTIONS + " INTEGER NOT NULL , "
            + COLUMN_SALARY + " INTEGER NOT NULL , "
            + COLUMN_CELL_NUMBER + " TEXT NOT NULL , "
            + COLUMN_HOME_NUMBER + " TEXT NOT NULL , "
            + COLUMN_ADDRESS + " TEXT NOT NULL , "
            + COLUMN_POST_ADDRESS + " INTEGER NOT NULL , "
            + COLUMN_POSTAL_CODE + " INTEGER NOT NULL , "
            + COLUMN_GENDER + " TEXT NOT NULL , "
            + COLUMN_RACE + " TEXT NOT NULL);";

    public EmployeeRepositoryImpl(Context context) {
        super(context, DBConstants.DATABASE_NAME, null, DBConstants.DATABASE_VERSION);
    }

    public void open() throws SQLException {
        db = this.getWritableDatabase();
    }

    public void close() {
        this.close();
    }

    @Override
    public Employee findById(long id) {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_EMPLOYEES,
                new String[]{
                        COLUMN_EMPLOYEE_NUMBER,
                        COLUMN_FIRST_NAME,
                        COLUMN_LAST_NAME,
                        COLUMN_NUMBER_OF_DEPENDANTS,
                        COLUMN_POSITION_CODE,
                        COLUMN_STATUS,
                        COLUMN_BENEFITS,
                        COLUMN_DEDUCTIONS ,
                         COLUMN_SALARY,
                        COLUMN_CELL_NUMBER,
                        COLUMN_HOME_NUMBER,
                        COLUMN_ADDRESS,
                        COLUMN_POST_ADDRESS,
                        COLUMN_POSTAL_CODE,
                        COLUMN_GENDER,
                        COLUMN_RACE},
                COLUMN_EMPLOYEE_NUMBER + " =? ",
                new String[]{String.valueOf(id)},
                null,
                null,
                null,
                null);
        if (cursor.moveToFirst()) {
            final Employee settings = new Employee
                    .Builder()
                    .employeeNumber((int) cursor.getInt(cursor.getColumnIndex(COLUMN_EMPLOYEE_NUMBER)))
                    .name(cursor.getString(cursor.getColumnIndex(COLUMN_FIRST_NAME)), cursor.getString(cursor.getColumnIndex(COLUMN_LAST_NAME)))
                    .numberOfDependants(cursor.getInt(cursor.getColumnIndex(COLUMN_NUMBER_OF_DEPENDANTS)))
                    .position(cursor.getString(cursor.getColumnIndex(COLUMN_POSITION_CODE)), cursor.getString(cursor.getColumnIndex(COLUMN_STATUS)), cursor.getInt(cursor.getColumnIndex(COLUMN_SALARY)),cursor.getInt(cursor.getColumnIndex(COLUMN_BENEFITS)), cursor.getInt(cursor.getColumnIndex(COLUMN_DEDUCTIONS)))
                    .contact(cursor.getString(cursor.getColumnIndex(COLUMN_CELL_NUMBER)), cursor.getString(cursor.getColumnIndex(COLUMN_HOME_NUMBER)))
                    .address(cursor.getString(cursor.getColumnIndex(COLUMN_ADDRESS)), cursor.getInt(cursor.getColumnIndex(COLUMN_POST_ADDRESS)), cursor.getInt(cursor.getColumnIndex(COLUMN_POSTAL_CODE)))
                    .demographics(cursor.getString(cursor.getColumnIndex(COLUMN_GENDER)), cursor.getString(cursor.getColumnIndex(COLUMN_RACE)))
                    .build();

            return settings;
        } else {
            return null;
        }
    }

    @Override
    public Employee save(Employee entity) {
        open();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FIRST_NAME, entity.getFirstName());
        values.put(COLUMN_LAST_NAME, entity.getLastName());
        values.put(COLUMN_NUMBER_OF_DEPENDANTS, entity.getNumberOfDependants());
        values.put(COLUMN_STATUS, entity.getPosition().getStatus());
        values.put(COLUMN_BENEFITS, entity.getPosition().getBenefits());
        values.put(COLUMN_DEDUCTIONS, entity.getPosition().getDeductions());
        values.put(COLUMN_SALARY, String.valueOf(entity.getPosition().getSalary()));
        values.put(COLUMN_CELL_NUMBER, entity.getContact().getCellNumber());
        values.put(COLUMN_HOME_NUMBER, entity.getContact().getHomeNumber());
        values.put(COLUMN_ADDRESS, entity.getAddress().getPhysicalAddress());
        values.put(COLUMN_POST_ADDRESS, entity.getAddress().getPostalAddress());
        values.put(COLUMN_POSTAL_CODE, entity.getAddress().getPostalCode());
        values.put(COLUMN_GENDER, entity.getDemographics().getGender());
        values.put(COLUMN_RACE, entity.getDemographics().getRace());
        long id =  db.insertOrThrow(TABLE_EMPLOYEES, null, values);
        Employee insertedEntity =  new Employee.Builder()
                .copy(entity)
                .employeeNumber(id)
                .build();
        return insertedEntity;
    }

    @Override
    public Employee update(Employee entity) {
        open();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FIRST_NAME, entity.getFirstName());
        values.put(COLUMN_LAST_NAME, entity.getLastName());
        values.put(COLUMN_NUMBER_OF_DEPENDANTS, entity.getNumberOfDependants());
        values.put(COLUMN_POSITION_CODE, entity.getNumberOfDependants());
        values.put(COLUMN_STATUS, entity.getNumberOfDependants());
        values.put(COLUMN_SALARY, entity.getNumberOfDependants());
        values.put(COLUMN_BENEFITS, entity.getNumberOfDependants());
        values.put(COLUMN_DEDUCTIONS, entity.getNumberOfDependants());
        values.put(COLUMN_CELL_NUMBER, entity.getContact().getCellNumber());
        values.put(COLUMN_HOME_NUMBER, entity.getContact().getHomeNumber());
        values.put(COLUMN_ADDRESS, entity.getAddress().getPhysicalAddress());
        values.put(COLUMN_POST_ADDRESS, entity.getAddress().getPostalAddress());
        values.put(COLUMN_POSTAL_CODE, entity.getAddress().getPostalCode());
        values.put(COLUMN_GENDER, entity.getDemographics().getGender());
        values.put(COLUMN_RACE, entity.getDemographics().getRace());
        long id =  db.insertOrThrow(TABLE_EMPLOYEES, null, values);
        db.update(
                TABLE_EMPLOYEES,
                values,
                COLUMN_EMPLOYEE_NUMBER + " =? ",
                new String[]{String.valueOf(entity.getEmployeeNumber())}
        );
        return entity;
    }

    public Employee delete(Employee entity) {
        open();
        db.delete(
                TABLE_EMPLOYEES,
                COLUMN_EMPLOYEE_NUMBER + " =? ",
                new String[]{String.valueOf(entity.getEmployeeNumber())});
        return entity;
    }

    @Override
    public Set<Employee> findAll() {
        SQLiteDatabase db = this.getReadableDatabase();
        Set<Employee> email = new HashSet<>();
        open();
        Cursor cursor = db.query(TABLE_EMPLOYEES, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                final Employee setting = new Employee.Builder()
                        .employeeNumber((int) cursor.getInt(cursor.getColumnIndex(COLUMN_EMPLOYEE_NUMBER)))
                        .name(cursor.getString(cursor.getColumnIndex(COLUMN_FIRST_NAME)), cursor.getString(cursor.getColumnIndex(COLUMN_LAST_NAME)))
                        .numberOfDependants(cursor.getInt(cursor.getColumnIndex(COLUMN_NUMBER_OF_DEPENDANTS)))
                        .position(cursor.getString(cursor.getColumnIndex(COLUMN_POSITION_CODE)), cursor.getString(cursor.getColumnIndex(COLUMN_STATUS)), cursor.getInt(cursor.getColumnIndex(COLUMN_SALARY)),cursor.getInt(cursor.getColumnIndex(COLUMN_BENEFITS)), cursor.getInt(cursor.getColumnIndex(COLUMN_DEDUCTIONS)))
                        .contact(cursor.getString(cursor.getColumnIndex(COLUMN_CELL_NUMBER)), cursor.getString(cursor.getColumnIndex(COLUMN_HOME_NUMBER)))
                        .address(cursor.getString(cursor.getColumnIndex(COLUMN_ADDRESS)), cursor.getInt(cursor.getColumnIndex(COLUMN_POST_ADDRESS)), cursor.getInt(cursor.getColumnIndex(COLUMN_POSTAL_CODE)))
                        .demographics(cursor.getString(cursor.getColumnIndex(COLUMN_GENDER)), cursor.getString(cursor.getColumnIndex(COLUMN_RACE)))
                        .build();
                email.add(setting);
            } while (cursor.moveToNext());
        }
        return email;
    }

    @Override
    public int deleteAll() {
        open();
        int rowsDeleted = db.delete(TABLE_EMPLOYEES, null, null);
        // close();
        return rowsDeleted;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(this.getClass().getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPLOYEES);
        onCreate(db);

    }
}

