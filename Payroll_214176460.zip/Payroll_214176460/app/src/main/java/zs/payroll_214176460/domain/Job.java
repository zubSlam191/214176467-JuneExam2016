package zs.payroll_214176460.domain;

import java.util.ArrayList;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class Job {
    private String jobTitle;
    private ArrayList<EmployeePosition> positions;
}
