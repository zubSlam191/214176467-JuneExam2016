package zs.payroll_214176460.factories;

import zs.payroll_214176460.domain.DriversLicense;
import zs.payroll_214176460.domain.Id;
import zs.payroll_214176460.domain.Passport;
import zs.payroll_214176460.domain.PersonIdentity;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class PersonIdentityFactory {

    public PersonIdentity getIdentity(String identityType){
        if(identityType == null){
            return null;
        }
        if(identityType.equalsIgnoreCase("Passport")){
            return new Passport();

        } else if(identityType.equalsIgnoreCase("ID")){
            return new Id();

        } else if(identityType.equalsIgnoreCase("DriversLicense")){
            return new DriversLicense();
        }

        return null;
    }

}
