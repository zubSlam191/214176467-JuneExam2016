package zs.payroll_214176460.conf;

/**
 * Created by 214176460 on 6/1/2016.
 */

public class DBConstants {
    public static final String DATABASE_NAME="payroll";
    public static final int DATABASE_VERSION=1;
}

