package zs.payroll_214176460.domain;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class Demographics {
    private String gender, race;

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }
}
