package zs.payroll_214176460.repositories;

/**
 * Created by 214176460 on 6/1/2016.
 */

import java.util.Set;

import zs.payroll_214176460.domain.Employee;

/**
 * Created by student on 2016/04/17.
 */
public interface Repository<E, ID> {

    E findById(long id);

    E save(Employee entity);

    E update(Employee entity);

    E delete(Employee entity);

    Set<E> findAll();

    int deleteAll();
}

