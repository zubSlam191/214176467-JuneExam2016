package zs.payroll_214176460.repositories.Employee;

import zs.payroll_214176460.domain.Employee;
import zs.payroll_214176460.repositories.Repository;

/**
 * Created by 214176460 on 6/1/2016.
 */
public interface EmployeeRepository extends Repository<Employee,Long> {
}
