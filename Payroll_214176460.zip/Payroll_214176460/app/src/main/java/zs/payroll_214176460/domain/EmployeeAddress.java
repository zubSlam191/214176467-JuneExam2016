package zs.payroll_214176460.domain;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class EmployeeAddress {

    private String physicalAddress;
    private Integer postalAddress,PostalCode;

    public EmployeeAddress(String physicalAddress, Integer postalAddress, Integer postalCode) {
        this.physicalAddress = physicalAddress;
        this.postalAddress = postalAddress;
        PostalCode = postalCode;
    }

    public String getPhysicalAddress() {
        return physicalAddress;
    }

    public void setPhysicalAddress(String physicalAddress) {
        this.physicalAddress = physicalAddress;
    }

    public Integer getPostalAddress() {
        return postalAddress;
    }

    public void setPostalAddress(Integer postalAddress) {
        this.postalAddress = postalAddress;
    }

    public Integer getPostalCode() {
        return PostalCode;
    }

    public void setPostalCode(Integer postalCode) {
        PostalCode = postalCode;
    }
}
