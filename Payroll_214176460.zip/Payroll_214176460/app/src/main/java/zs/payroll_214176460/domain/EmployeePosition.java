package zs.payroll_214176460.domain;

import java.util.ArrayList;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class EmployeePosition {
    private String positionCode, status;
    private EmployeeSalary salary;
    private Integer benefits;
    private Integer deductions;

    public EmployeePosition() {
    }

    public String getPositionCode() {
        return positionCode;
    }

    public void setPositionCode(String positionCode) {
        this.positionCode = positionCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public EmployeeSalary getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary.setBaseSalary(salary);
    }

    public Integer getBenefits() {
        return benefits;
    }

    public void setBenefits(Integer benefits) {
        this.benefits = benefits;
    }

    public Integer getDeductions() {
        return deductions;
    }

    public void setDeductions(Integer deductions) {
        this.deductions = deductions;
    }
}
