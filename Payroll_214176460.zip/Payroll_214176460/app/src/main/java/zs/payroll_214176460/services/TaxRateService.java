package zs.payroll_214176460.services;

import android.app.IntentService;
import android.content.Intent;

import zs.payroll_214176460.conf.GetContext;
import zs.payroll_214176460.repositories.Employee.Impl.EmployeeRepositoryImpl;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p/>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class TaxRateService extends IntentService {


    public TaxRateService() {
        super("TaxRateService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        EmployeeRepositoryImpl empRepo = new EmployeeRepositoryImpl(GetContext.getStaticContext());

        if (intent != null) {

            int payDummy = 0;
            getTax(payDummy);
        }
    }

    public Integer getTax(Integer grossPay){
        if (grossPay>6000 && grossPay<=10000)
            return 10;
        else if (grossPay>10000 && grossPay<=20000)
            return 20;
        else if (grossPay>20000 && grossPay<=30000)
            return 30;
        else if (grossPay>30000 && grossPay<=40000)
            return 40;
        else if (grossPay>40000 && grossPay<=50000)
            return 50;
        else return 0;
    }

}
