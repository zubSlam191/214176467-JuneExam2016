package zs.payroll_214176460.domain;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class EmployeeContact {
    private String cellNumber, homeNumber;

    public String getCellNumber() {
        return cellNumber;
    }

    public void setCellNumber(String cellNumber) {
        this.cellNumber = cellNumber;
    }

    public String getHomeNumber() {
        return homeNumber;
    }

    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber;
    }
}
