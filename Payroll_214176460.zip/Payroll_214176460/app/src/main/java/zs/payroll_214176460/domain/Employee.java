package zs.payroll_214176460.domain;

import android.provider.ContactsContract;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by 214176460 on 6/1/2016.
 */
public class Employee implements PersonIdentity, PersonName {


    private PersonName name;
    private long employeeNumber;
    private Integer numberOfDependants;
    private EmployeeAddress address;
    private EmployeeContact contact;
    private Demographics demographics;
    private EmployeePosition position;
    private EmployeePayslip payslip;

    @Override
    public String getIdValue() {
        return this.getIdValue();
    }

    @Override
    public String getIdType() {
        return this.getIdType();
    }

    @Override
    public String getFirstName() {
        return this.name.getFirstName();
    }

    @Override
    public String getLastName() {
        return this.name.getLastName();
    }
    @Override
    public void setFirstName(String name){this.name.setFirstName(name);}
    @Override
    public void setLastName(String surname){this.name.setLastName(surname);}

    public Employee() {
    }

    public PersonName getName() {
        return name;
    }

    public void setName(PersonName name) {
        this.name = name;
    }

    public Integer getNumberOfDependants() {
        return numberOfDependants;
    }

    public void setNumberOfDependants(Integer numberOfDependants) {
        this.numberOfDependants = numberOfDependants;
    }

    public long getEmployeeNumber() {
        return employeeNumber;
    }

    public void setEmployeeNumber(Integer employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    public EmployeeAddress getAddress() {
        return address;
    }

    public void setAddress(EmployeeAddress address) {
        this.address = address;
    }

    public EmployeeContact getContact() {
        return contact;
    }

    public void setContact(EmployeeContact contact) {
        this.contact = contact;
    }

    public Demographics getDemographics() {
        return demographics;
    }

    public void setDemographics(Demographics demographics) {
        this.demographics = demographics;
    }

    public EmployeePosition getPosition() {
        return position;
    }

    public void setPosition(EmployeePosition position) {
        this.position = position;
    }

    public EmployeePayslip getPayslip() {
        return payslip;
    }

    public void setPayslips(EmployeePayslip payslip) {
        this.payslip = payslip;
    }



    public static class Builder {
        private PersonName name;
        private Integer numberOfDependants;
        private long employeeNumber;
        private EmployeeAddress address;
        private EmployeeContact contact;
        private Demographics demographics;
        private EmployeePosition position;
        private EmployeePayslip payslip;

        public Builder employeeNumber(long value) {
            this.employeeNumber = value;
            return this;
        }

        public Builder name(String value, String value2) {
            this.name.setFirstName(value);
            this.name.setLastName(value2);
            return this;
        }

        public Builder numberOfDependants(Integer value) {
            this.numberOfDependants = value;
            return this;
        }

        public Builder address(String value, Integer value2, Integer value3) {
            this.address.setPhysicalAddress(value);
            this.address.setPostalAddress(value2);
            this.address.setPostalCode(value3);
            return this;
        }
        public Builder contact(String value, String value2) {
            this.contact.setCellNumber(value);
            this.contact.setHomeNumber(value2);
            return this;
        }
        public Builder demographics(String value, String value2) {
            this.demographics.setGender(value);
            this.demographics.setRace(value2);
            return this;
        }
        public Builder position(String value, String value2,Integer value3,Integer value4,Integer  value5) {
            this.position.setPositionCode(value);
            this.position.setStatus(value2);
            this.position.setSalary(value3);
            this.position.setBenefits(value4);
            this.position.setDeductions(value5);
            return this;
        }public Builder payslip(BigDecimal value, BigDecimal value2, BigDecimal value3, BigDecimal value4, Date value5) {
            this.payslip.getGrossPay();
            return this;
        }



        public Builder copy(Employee value) {
            this.employeeNumber = value.getEmployeeNumber();
            this.numberOfDependants = value.getNumberOfDependants();
            this.address = value.getAddress();
            this.contact = value.getContact();
            this.demographics = value.getDemographics();
            this.position = value.getPosition();
            this.payslip = value.getPayslip();

            return this;
        }

        public Employee build() {
            return new Employee() {
                };
        }

    }
}
